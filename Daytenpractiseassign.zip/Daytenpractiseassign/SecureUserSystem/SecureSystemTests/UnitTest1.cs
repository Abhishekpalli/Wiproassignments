﻿using System;
using System.IO;
using NUnit.Framework;
using SecureUserSystem; // Access your core logic 

namespace SecureSystemTests
{
    public class Tests
    {
        private User _user;

        [SetUp]
        public void Setup()
        {
            _user = new User();
        }

        [Test]
        public void Register_ShouldHashPassword() // Task 4.1: Test Hashing
        {
            string password = "MySecurePassword123";
            _user.Register("Abhishek", password);

            // Verify password is not stored in plain text
            Assert.That(_user.HashedPassword, Is.Not.EqualTo(password));
            Assert.That(_user.Authenticate(password), Is.True);
        }

        [Test]
        public void Encryption_ShouldEncryptAndDecryptCorrectly() // Task 4.2: Test Encryption
        {
            string originalData = "SensitiveInfo";
            string encrypted = EncryptionHelper.Encrypt(originalData);
            string decrypted = EncryptionHelper.Decrypt(encrypted);

            Assert.That(encrypted, Is.Not.EqualTo(originalData));
            Assert.That(decrypted, Is.EqualTo(originalData));
        }

        [Test]
        public void Logging_ShouldWriteToFileOnException() // Task 4.3 & 4.4: Test Logging
        {
            string logPath = "app_log.txt";
            if (File.Exists(logPath))
                File.Delete(logPath);

            try
            {
                throw new Exception("Test Error");
            }
            catch (Exception ex)
            {
                LoggerService.LogError(ex); // Log the error
            }

            Assert.That(File.Exists(logPath), Is.True);

            string logContent = File.ReadAllText(logPath);
            Assert.That(logContent.Contains("Test Error"), Is.True);
        }
    }
}