﻿using System;
using System.IO;

namespace SecureUserSystem
{
    public static class LoggerService
    {
        private static string logFile = "app_log.txt";

        public static void LogInfo(string message)
        {
            File.AppendAllText(logFile, $"{DateTime.Now}: INFO - {message}\n");
        }

        public static void LogError(Exception ex)
        {
            // Logging without exposing sensitive data in the UI
            string logMessage = $"{DateTime.Now}: ERROR - {ex.Message}\nStack Trace: {ex.StackTrace}\n";
            File.AppendAllText(logFile, logMessage);
        }
    }
}