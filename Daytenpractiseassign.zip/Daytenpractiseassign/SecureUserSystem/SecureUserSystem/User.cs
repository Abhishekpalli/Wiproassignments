﻿using System.Security.Cryptography;
using System.Text;

namespace SecureUserSystem
{
    public class User
    {
        public string Username { get; set; }
        public string HashedPassword { get; private set; }

        // Register a new user with a hashed password
        public void Register(string username, string password)
        {
            Username = username;
            HashedPassword = HashPassword(password);
        }

        // Authenticate by comparing the hash of the entered password
        public bool Authenticate(string password)
        {
            return HashedPassword == HashPassword(password);
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }
    }
}