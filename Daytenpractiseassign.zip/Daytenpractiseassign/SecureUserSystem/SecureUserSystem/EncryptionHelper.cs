﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace SecureUserSystem
{
    public static class EncryptionHelper
    {
        private static readonly byte[] Key = Encoding.UTF8.GetBytes("1234567890123456"); // 16-byte key
        private static readonly byte[] IV = Encoding.UTF8.GetBytes("1234567890123456");  // 16-byte IV

        public static string Encrypt(string plainText)
        {
            using Aes aes = Aes.Create();
            aes.Key = Key;
            aes.IV = IV;

            using var encryptor = aes.CreateEncryptor();
            byte[] input = Encoding.UTF8.GetBytes(plainText);
            byte[] output = encryptor.TransformFinalBlock(input, 0, input.Length);

            return Convert.ToBase64String(output);
        }

        public static string Decrypt(string cipherText)
        {
            using Aes aes = Aes.Create();
            aes.Key = Key;
            aes.IV = IV;

            using var decryptor = aes.CreateDecryptor();
            byte[] input = Convert.FromBase64String(cipherText);
            byte[] output = decryptor.TransformFinalBlock(input, 0, input.Length);

            return Encoding.UTF8.GetString(output);
        }
    }
}