﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringPractice
{
    internal class PalindromeHw
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a sentence:");
            string sentence = Console.ReadLine();

            string[] words = sentence.Split(' ');
            int count = 0;

            foreach (string word in words)
            {
                string lower = word.ToLower();
                char[] arr = lower.ToCharArray();
                Array.Reverse(arr);
                string reversed = new string(arr);

                if (lower == reversed)
                {
                    count++;
                }
            }

            Console.WriteLine("Total Count of Palindrome Words: " + count);
        }
    }

}
