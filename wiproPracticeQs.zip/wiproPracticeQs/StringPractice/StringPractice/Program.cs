﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    namespace StringPractice
    {
        internal class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("Enter a sentence:");
                string sentence = Console.ReadLine();
                string[] words = sentence.Split(' ');

                for (int i = 0; i < words.Length; i++)
                {
                    if (i % 2 != 0)
                    {
                        char[] arr = words[i].ToCharArray();
                        Array.Reverse(arr);
                        words[i] = new string(arr);
                    }
                }

                Console.WriteLine("reversedalternative:");
                Console.WriteLine(string.Join(" ", words));
            }
        }
    }
