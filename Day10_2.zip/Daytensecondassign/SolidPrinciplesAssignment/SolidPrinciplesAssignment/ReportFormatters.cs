﻿namespace SolidPrinciplesAssignment
{
    // PDF Formatting Strategy
    public class PdfFormatter : IReportFormatter
    {
        public string Format(string content)
        {
            return "PDF FORMAT:\n" + content;
        }
    }

    // Excel Formatting Strategy
    public class ExcelFormatter : IReportFormatter
    {
        public string Format(string content)
        {
            return "EXCEL FORMAT:\n" + content;
        }
    }
}