﻿using System;

namespace SolidPrinciplesAssignment
{
    // SRP: Only responsible for generating report data
    public class ReportGenerator
    {
        public string GenerateReport()
        {
            return "Wipro NGA .NET Cohort Report Data";
        }
    }

    // SRP: Only responsible for saving report to file
    public class ReportSaver
    {
        public void SaveToFile(string filename, string content)
        {
            System.IO.File.WriteAllText(filename, content);
            Console.WriteLine($"Report saved to {filename}");
        }
    }

    // DIP: Depends on abstraction (IReportFormatter)
    public class ReportService
    {
        private readonly IReportFormatter _formatter;

        public ReportService(IReportFormatter formatter)
        {
            _formatter = formatter;
        }

        public string ProcessReport(string rawData)
        {
            return _formatter.Format(rawData);
        }
    }
}