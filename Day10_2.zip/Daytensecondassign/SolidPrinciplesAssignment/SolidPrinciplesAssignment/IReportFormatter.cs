﻿namespace SolidPrinciplesAssignment
{
    // OCP: Abstraction for formatting strategies
    public interface IReportFormatter
    {
        string Format(string content);
    }
}