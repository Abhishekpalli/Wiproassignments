﻿using System;

namespace SolidPrinciplesAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            // Singleton Logger
            Logger logger = Logger.Instance;
            logger.Log("Application Started.");

            // SRP: Generate Report
            ReportGenerator generator = new ReportGenerator();
            string reportData = generator.GenerateReport();
            logger.Log("Report generated successfully.");

            // OCP + DIP: Choose formatter dynamically
            Console.WriteLine("Select Report Format: (1) PDF  (2) Excel");
            string input = Console.ReadLine();

            IReportFormatter formatter;

            if (input == "1")
            {
                formatter = new PdfFormatter();
            }
            else
            {
                formatter = new ExcelFormatter();
            }

            // Process Report
            ReportService service = new ReportService(formatter);
            string formattedReport = service.ProcessReport(reportData);
            logger.Log("Report formatted successfully.");

            Console.WriteLine("\nFormatted Output:");
            Console.WriteLine(formattedReport);

            // Save Report
            ReportSaver saver = new ReportSaver();
            saver.SaveToFile("FinalReport.txt", formattedReport);
            logger.Log("Report saved successfully.");

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();

            SolidPrinciplesAssignment.Logger logger = SolidPrinciplesAssignment.Logger.Instance;
        }
    }
}