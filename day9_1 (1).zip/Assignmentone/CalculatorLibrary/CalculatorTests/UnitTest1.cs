﻿using NUnit.Framework;
using CalculatorLibrary;

namespace CalculatorTests
{
    public class Tests
    {
        private Calculator _calculator;

        [SetUp]
        public void Setup()
        {
            _calculator = new Calculator();
        }

        [Test]
        public void Add_ValidInputs_ReturnsCorrectSum()
        {
            double result = _calculator.Add(10, 5);
            Assert.That(result, Is.EqualTo(15));
        }

        [Test]
        public void Subtract_EdgeCase_SubtractZero()
        {
            double result = _calculator.Subtract(10, 0);
            Assert.That(result, Is.EqualTo(10));
        }

        [Test]
        public void Divide_ByZero_ThrowsException()
        {
            Assert.That(() => _calculator.Divide(10, 0),
                        Throws.TypeOf<System.DivideByZeroException>());
        }
    }
}