var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// User Story 2: Configure logging middleware
app.Use(async (context, next) =>
{
    // Log request details
    Console.WriteLine($"Incoming Request: {context.Request.Method} {context.Request.Path}");

    await next.Invoke(); // Pass request to the next component

    // Log response status code
    Console.WriteLine($"Outgoing Response: {context.Response.StatusCode}");
});

// User Story 2: Configure custom error handling
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}

// User Story 4: Enforce HTTPS
// User Story 4: Implement Content Security Policy
app.Use(async (context, next) =>
{
    context.Response.Headers.Add("Content-Security-Policy", "default-src 'self';");
    await next();
});

// User Story 3: Enable serving static files from wwwroot
app.UseStaticFiles();

app.MapGet("/", () => "The .NET Web App is running with Middleware!");

app.Run();