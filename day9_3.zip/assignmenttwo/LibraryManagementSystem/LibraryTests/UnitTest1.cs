﻿using NUnit.Framework;
using LibraryManagementSystem;

namespace LibraryTests
{
    public class Tests
    {
        private Library _library;

        [SetUp]
        public void Setup()
        {
            _library = new Library();
        }

        [Test]
        public void AddBook_ShouldAddCorrectly()
        {
            var book = new Book("C# Basics", "Wipro", "123-ABC");

            _library.AddBook(book);

            Assert.That(_library.Books.Count, Is.EqualTo(1));
        }

        [Test]
        public void RegisterBorrower_ShouldRegisterCorrectly()
        {
            var borrower = new Borrower("Abhishek", "LIB-001");

            _library.RegisterBorrower(borrower);

            Assert.That(_library.Borrowers.Count, Is.EqualTo(1));
        }

        [Test]
        public void BorrowBook_ShouldMarkAsBorrowedAndAssociate()
        {
            var book = new Book("Unit Testing", "NGA", "456-DEF");
            var borrower = new Borrower("Abhishek", "LIB-001");

            _library.AddBook(book);
            _library.RegisterBorrower(borrower);

            _library.BorrowBook("456-DEF", "LIB-001");

            Assert.That(book.IsBorrowed, Is.True);
            Assert.That(borrower.BorrowedBooks.Contains(book), Is.True);
        }

        [Test]
        public void ReturnBook_ShouldMarkAsAvailableAndRemoveFromBorrower()
        {
            var book = new Book("Clean Code", "Robert", "789-GHI");
            var borrower = new Borrower("Abhishek", "LIB-001");

            _library.AddBook(book);
            _library.RegisterBorrower(borrower);
            _library.BorrowBook("789-GHI", "LIB-001");

            _library.ReturnBook("789-GHI", "LIB-001");

            Assert.That(book.IsBorrowed, Is.False);
            Assert.That(borrower.BorrowedBooks.Count, Is.EqualTo(0));
        }
    }
}