﻿using System.Collections.Generic;
using System.Linq;

namespace LibraryManagementSystem
{
    public class Library
    {
        public List<Book> Books { get; set; } = new List<Book>();
        public List<Borrower> Borrowers { get; set; } = new List<Borrower>();

        public void AddBook(Book book) => Books.Add(book);

        public void RegisterBorrower(Borrower borrower) => Borrowers.Add(borrower);

        public void BorrowBook(string isbn, string libraryCardNumber)
        {
            var book = Books.FirstOrDefault(b => b.ISBN == isbn && !b.IsBorrowed);
            var borrower = Borrowers.FirstOrDefault(br => br.LibraryCardNumber == libraryCardNumber);

            if (book != null && borrower != null)
            {
                book.Borrow();
                borrower.BorrowBook(book);
            }
        }

        public void ReturnBook(string isbn, string libraryCardNumber)
        {
            var borrower = Borrowers.FirstOrDefault(br => br.LibraryCardNumber == libraryCardNumber);
            var book = borrower?.BorrowedBooks.FirstOrDefault(b => b.ISBN == isbn);

            if (book != null)
            {
                book.Return();
                borrower.ReturnBook(book);
            }
        }

        public void ViewBooks()
        {
            // Lists all books, their details, and status
            foreach (var book in Books)
            {
                string status = book.IsBorrowed ? "Borrowed" : "Available";
                Console.WriteLine($"Title: {book.Title}, Author: {book.Author}, ISBN: {book.ISBN}, Status: {status}");
            }
        }

        public void ViewBorrowers()
        {
            // Lists all borrowers and their current borrowed books
            foreach (var borrower in Borrowers)
            {
                Console.WriteLine($"Borrower: {borrower.Name}, Card: {borrower.LibraryCardNumber}");
                Console.WriteLine($"Borrowed Books count: {borrower.BorrowedBooks.Count}");
            }
        }
    }
}