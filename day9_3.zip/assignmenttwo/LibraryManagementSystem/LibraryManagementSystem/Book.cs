﻿using System;

namespace LibraryManagementSystem
{
    // Task 1: Implement Book Class
    public class Book
    {
        // Properties
        public string Title { get; set; }
        public string Author { get; set; }
        public string ISBN { get; set; }
        public bool IsBorrowed { get; set; }

        // Constructor
        public Book(string title, string author, string isbn)
        {
            Title = title;
            Author = author;
            ISBN = isbn;
            IsBorrowed = false; // Available by default
        }

        // Mark book as borrowed
        public void Borrow()
        {
            IsBorrowed = true;
        }

        // Mark book as returned
        public void Return()
        {
            IsBorrowed = false;
        }
    }
}