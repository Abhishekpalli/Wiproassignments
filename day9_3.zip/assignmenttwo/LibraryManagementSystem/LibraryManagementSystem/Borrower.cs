﻿using System.Collections.Generic;

namespace LibraryManagementSystem
{
    // Task 1: Implement Borrower Class
    public class Borrower
    {
        // Properties
        public string Name { get; set; }
        public string LibraryCardNumber { get; set; }

        // List of borrowed books
        public List<Book> BorrowedBooks { get; set; } = new List<Book>();

        // Constructor
        public Borrower(string name, string libraryCardNumber)
        {
            Name = name;
            LibraryCardNumber = libraryCardNumber;
        }

        // Add book to borrower
        public void BorrowBook(Book book)
        {
            BorrowedBooks.Add(book);
        }

        // Remove book from borrower
        public void ReturnBook(Book book)
        {
            BorrowedBooks.Remove(book);
        }
    }
}