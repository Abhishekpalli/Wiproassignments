﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReduceStringByK
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(ReduceString("qddxxxd", 3));
            Console.WriteLine(ReduceString("geeksforgeeks", 2));
            Console.ReadLine();
        }

        static string ReduceString(string str, int k)
        {
            if (k == 1) return "";

            Stack<(char ch, int count)> stack = new Stack<(char, int)>();

            foreach (char c in str)
            {
                if (stack.Count > 0 && stack.Peek().ch == c)
                {
                    var top = stack.Pop();
                    top.count++;

                    if (top.count < k)
                    {
                        stack.Push(top);
                    }
                }
                else
                {
                    stack.Push((c, 1));
                }
            }

            StringBuilder result = new StringBuilder();
            var finalArray = stack.ToArray();
            Array.Reverse(finalArray);

            foreach (var item in finalArray)
            {
                for (int i = 0; i < item.count; i++)
                {
                    result.Append(item.ch);
                }
            }

            return result.ToString();

        }

       }
}
