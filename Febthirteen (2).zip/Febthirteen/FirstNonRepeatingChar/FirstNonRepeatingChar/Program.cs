﻿using System;
using System.Collections.Generic;

namespace FirstNonRepeating
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = "geeksforgeeks";
            Console.WriteLine($"Input: {s}");
            Console.WriteLine($"Output: {FindFirstNonRepeating(s)}");
        }

        static char FindFirstNonRepeating(string s)
        {
            Dictionary<char, int> counts = new Dictionary<char, int>();

            // Count occurrences of each character
            foreach (char c in s)
            {
                if (counts.ContainsKey(c)) counts[c]++;
                else counts[c] = 1;
            }

            // Find the first character with a count of 1
            foreach (char c in s)
            {
                if (counts[c] == 1) return c;
            }

            return '$';
        }
    }
}