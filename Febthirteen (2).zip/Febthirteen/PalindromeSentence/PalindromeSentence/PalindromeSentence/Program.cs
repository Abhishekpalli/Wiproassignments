﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PalindromeSentence
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string s1 = "Too hot to hoot.";
            Console.WriteLine(IsPalindrome(s1));

            string s2 = "Abc 012..##  10cbA";
            Console.WriteLine(IsPalindrome(s2));

            string s3 = "ABC $. def01ASDF..";
            Console.WriteLine(IsPalindrome(s3));

            Console.ReadLine();
        }

        static bool IsPalindrome(string s)
        {
            int left = 0;
            int right = s.Length - 1;

            while (left < right)
            {
                if (!char.IsLetterOrDigit(s[left]))
                {
                    left++;
                    continue;
                }
                if (!char.IsLetterOrDigit(s[right]))
                {
                    right--;
                    continue;
                }

                if (char.ToLower(s[left]) != char.ToLower(s[right]))
                {
                    return false;
                }

                left++;
                right--;
            }
            return true;
        }
    }
}
