// Function to fetch employee data
async function getEmployees() {
    const url = "https://dummy.restapiexample.com/api/v1/employees";
    
    try {
        const response = await fetch(url);
        // Convert the response to JSON
        const data = await response.json();
        // Display the data in the console [cite: 3]
        console.log("Employee Data:", data);
    } catch (error) {
        console.error("Error fetching data:", error);
    }
}

getEmployees();