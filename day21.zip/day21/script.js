const button = document.getElementById('fetchUser');
const userCard = document.getElementById('userCard');

button.addEventListener('click', () => {
    fetch("https://randomuser.me/api/")
        .then(response => response.json())
        .then(data => {
            const user = data.results[0];
            // Display name, email, and profile picture 
            userCard.innerHTML = `
                <img src="${user.picture.large}" alt="Profile Picture">
                <p><strong>Name:</strong> ${user.name.first} ${user.name.last}</p>
                <p><strong>Email:</strong> ${user.email}</p>
            `;
        })
        .catch(err => console.log(err));
});